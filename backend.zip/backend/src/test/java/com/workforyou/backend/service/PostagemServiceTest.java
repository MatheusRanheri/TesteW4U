package com.workforyou.backend.service;

import com.workforyou.backend.model.Postagem;
import com.workforyou.backend.model.Prestador;
import com.workforyou.backend.model.Servico;
import com.workforyou.backend.repository.PostagemRepository;
import com.workforyou.backend.repository.PrestadorRepository;
import com.workforyou.backend.repository.ServicoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PostagemServiceTest {

    @Mock
    private PostagemRepository postagemRepository;

    @Mock
    private PrestadorRepository prestadorRepository;

    @Mock
    private ServicoRepository servicoRepository;

    @InjectMocks
    private PostagemService postagemService;

    @Test
    public void testaCriarNovaPostagem(){
        String foto = "urlFoto";
        String descricao = "baita postagem";
        String cnpj = "12346789633456";
        Long idServico = 1L;

        Prestador prestador = new Prestador();
        Servico servico = new Servico();
        Postagem postagemSalva  = new Postagem();

        when(postagemRepository.save(any(Postagem.class))).thenReturn(postagemSalva);
        when(prestadorRepository.findByCnpj(cnpj)).thenReturn(Optional.of(prestador));
        when(servicoRepository.findById(idServico)).thenReturn(Optional.of(servico));
        when(postagemRepository.findByServicoId(idServico)).thenReturn(Optional.empty());

        Postagem resultado = postagemService.salvarNovaPostagem(foto, descricao, cnpj, idServico);

        assertNotNull(resultado);
        verify(postagemRepository).save(any(Postagem.class));
    }

    @Test
    public void testaPrestadorNaoEncontradoNegativo(){
        String foto = "foto";
        String descricao = "baita postagem";
        String cnpj = "99999999999999";
        Long idServico = 1L;

        when(postagemRepository.findByServicoId(idServico)).thenReturn(Optional.empty());
        when(prestadorRepository.findByCnpj(cnpj)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, ()-> {
            postagemService.salvarNovaPostagem(foto, descricao, cnpj, idServico);
        });

        assertEquals("Prestador não encontrado para o CNPJ: " + cnpj, ex.getMessage());
        verify(postagemRepository, never()).save(any(Postagem.class));
    }

    @Test public void testaServicoNaoEncontradoNegativo(){
        String foto = "foto";
        String descricao = "baita postagem";
        String cnpj = "12345678000199";
        Long idServico = 1L;

        Prestador prestador = new Prestador();

        when(postagemRepository.findByServicoId(idServico)).thenReturn(Optional.empty());
        when(prestadorRepository.findByCnpj(cnpj)).thenReturn(Optional.of(prestador));
        when(servicoRepository.findById(idServico)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () ->
                postagemService.salvarNovaPostagem(foto, descricao, cnpj, idServico)
        );

        assertEquals("Serviço não encontrado com o ID: " + idServico, ex.getMessage());
        verify(postagemRepository, never()).save(any(Postagem.class));
    }

    @Test
    public void testaPostagemJaCriada(){
        String foto = "urlFoto";
        String descricao = "baita postagem";
        String cnpj = "12345678900012";
        Long idServico = 1L;

        Prestador prestador = new Prestador();
        Servico servico = new Servico();
        Postagem postagemSalva = new Postagem();

        when(postagemRepository.findByServicoId(idServico)).thenReturn(Optional.empty());
        when(prestadorRepository.findByCnpj(cnpj)).thenReturn(Optional.of(prestador));
        when(servicoRepository.findById(idServico)).thenReturn(Optional.of(servico));
        when(postagemRepository.save(any(Postagem.class))).thenReturn(postagemSalva);

        Postagem resultado = postagemService.salvarNovaPostagem(foto, descricao, cnpj, idServico);

        assertNotNull(resultado);
        verify(postagemRepository).save(any(Postagem.class));
        verify(postagemRepository).findByServicoId(idServico);
        verify(prestadorRepository).findByCnpj(cnpj);
        verify(servicoRepository).findById(idServico);
    }

    @Test
    public void testaPostagemJaCriadaNegativo(){
        String foto = "foto";
        String descricao = "Postagem que ja existe";
        String cnpj = "12345678000199";
        Long idServico = 1L;

        when(postagemRepository.findByServicoId(idServico)).thenReturn(Optional.of(new Postagem()));

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
           postagemService.salvarNovaPostagem(foto, descricao, cnpj, idServico);
        });

        assertEquals("Postagem já criada com esse serviço!", ex.getMessage());
        verify(postagemRepository, never()).save(any(Postagem.class));
    }


}
