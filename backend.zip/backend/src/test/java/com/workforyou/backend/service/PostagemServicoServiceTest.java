package com.workforyou.backend.service;


import com.workforyou.backend.dto.RegistroRequest;
import com.workforyou.backend.model.PessoaJuridica;
import com.workforyou.backend.model.Postagem;
import com.workforyou.backend.model.Servico;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.support.SimpleTriggerContext;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PostagemServicoServiceTest {

    @Mock
    private ServicoService servicoService;

    @Mock
    private PostagemService postagemService;

    @InjectMocks
    private PostagemServicoService postagemServicoService;

    @Test
    public void criarPostagemTeste(){
        String nomeServico = "Eletricista";
        String tipoServico = "Reparo";
        String descricaoS = "Baita servico";
        String descricaoP = "Baita prestador";
        String cnpj = "52534636563566";
        String foto = "foto";

        Servico servicoSalvo = new Servico();
        servicoSalvo.setId(1L);

        when(servicoService.salvarServico(nomeServico, tipoServico, descricaoS, cnpj)).thenReturn(servicoSalvo);

        when(postagemService.salvarNovaPostagem(foto, descricaoP, cnpj, servicoSalvo.getId())).thenReturn(new Postagem());

        postagemServicoService.criarPostagemServico(nomeServico, tipoServico, descricaoS, descricaoP, cnpj, foto);

        verify(servicoService, times(1)).salvarServico(nomeServico, tipoServico, descricaoS, cnpj);
        verify(postagemService, times(1)).salvarNovaPostagem(foto, descricaoP, cnpj, servicoSalvo.getId());
    }

    @Test
    public void testaCriarPostagemNegativo(){
        String nomeServico = "Eletricista";
        String tipoServico = "Reparo";
        String descricaoS = "Baita servico";
        String descricaoP = "Baita prestador";
        String cnpj = "52534636563566";
        String foto = "foto";

        when(servicoService.salvarServico(nomeServico, tipoServico, descricaoS, cnpj)).thenThrow(new RuntimeException("Erro ao salvar servico"));

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            postagemServicoService.criarPostagemServico(nomeServico, tipoServico, descricaoS, descricaoP, cnpj, foto);
        });

        assertEquals("Erro ao salvar servico", ex.getMessage());

        verify(postagemService, never()).salvarNovaPostagem(anyString(), anyString(), anyString(), anyLong());
    }
}
