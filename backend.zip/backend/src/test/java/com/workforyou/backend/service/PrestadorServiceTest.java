package com.workforyou.backend.service;

import com.workforyou.backend.dto.RegistroRequest;
import com.workforyou.backend.model.PessoaJuridica;
import com.workforyou.backend.model.Prestador;
import com.workforyou.backend.repository.PrestadorRepository;
import jakarta.persistence.Table;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PrestadorServiceTest {

    @Mock
    private PrestadorRepository prestadorRepository;

    @InjectMocks
    private PrestadorService prestadorService;

    @Test
    public void testaCriarPrestador(){
        RegistroRequest request = new RegistroRequest();
        request.setEmail("pessoa@gmail.com");
        request.setUriFoto("foto");
        request.setEspecialidade("reparos");

        PessoaJuridica pessoaJuridica = new PessoaJuridica();
        pessoaJuridica.setCnpj("12414423432599");

        Prestador prestadorSalvo = new Prestador();
        prestadorSalvo.setId(1L);
        prestadorSalvo.setEmail("pessoa@gmail.com");
        prestadorSalvo.setUrlFoto("foto");
        prestadorSalvo.setEspecialidade("reparos");
        prestadorSalvo.setPessoaJuridica(pessoaJuridica);

        when(prestadorRepository.save(any(Prestador.class))).thenReturn(prestadorSalvo);

        Prestador resultado = prestadorService.criarPrestador(request, pessoaJuridica);

        assertNotNull(resultado);
        assertEquals("pessoa@gmail.com", resultado.getEmail());
        assertEquals("foto", resultado.getUrlFoto());
        assertEquals("reparos", resultado.getEspecialidade());
        assertEquals("12414423432599", resultado.getPessoaJuridica().getCnpj());

        verify(prestadorRepository, times(1)).save(any(Prestador.class));
    }

    @Test
    public void testaCriarPrestadorNegativo(){
        RegistroRequest request = new RegistroRequest();
        request.setEmail("erro@email.com");
        request.setUriFoto("foto.png");
        request.setEspecialidade("Pintor");

        PessoaJuridica pessoaJuridica = new PessoaJuridica();
        pessoaJuridica.setCnpj("12414423432599");

        when(prestadorRepository.save(any(Prestador.class))).thenThrow(new RuntimeException("Erro ao salvar no banco"));

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            prestadorService.criarPrestador(request, pessoaJuridica);
        });

        assertEquals("Erro ao salvar no banco", ex.getMessage());
        verify(prestadorRepository, times(1)).save(any(Prestador.class));
    }

}
