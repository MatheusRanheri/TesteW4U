package com.workforyou.backend.controller;

public class AuthControllerTeste {
}
